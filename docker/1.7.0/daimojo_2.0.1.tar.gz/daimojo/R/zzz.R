# Copyright © 2018 - 2019 H2O.AI Inc. All rights reserved.

loadModule("rcppmojo", TRUE)

